//
//  PMBaseViewController.h
//  Pathmapp
//
//  Created by Salil Malkan on 9/27/12.
//  Copyright (c) 2012 Salil Malkan. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PMBaseViewController : UIViewController
{    
}

@property (readonly) BOOL layoutLoaded;
- (void) loadPMBWithData:(NSData *)pmbData;

@end
