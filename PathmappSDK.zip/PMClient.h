//
//  PMClient.h
//
//
//  Created by Salil Malkan on 1/21/13.
//  Copyright (c) 2013 Salil Malkan. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PMClient : NSObject

+ (void) startMappingWithOptions:(id) firstOption, ...;
+ (void) handleURL:(NSURL *) url;

@end
